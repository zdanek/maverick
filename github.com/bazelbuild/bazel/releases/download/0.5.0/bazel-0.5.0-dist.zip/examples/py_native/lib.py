"""A tiny example binary for the native Python rules of Bazel."""


def GetNumber():
  return 42
