---
layout: redirect
redirect: docs/best-practices.html
---
