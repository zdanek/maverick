---
layout: contribute
title: Bazel Users
---

Find a community curated a list of Bazel users in the [Bazel GitHub wiki](https://github.com/bazelbuild/bazel/wiki/Bazel-Users)